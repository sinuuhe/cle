var tabla;

function elegirBeca(selectName){
	
	console($("#" + selectName).attr("data-des"));
}
//Función que se ejecuta al inicio
function init(){
	mostrarform(false);
	listar();
	listarConvenio();
	$("#fecha_nacimiento,#fecha_ingreso").datepicker({
		format:"yyyy-mm-dd"
	});
	$("#formulario").on("submit",function(e)
	{
		guardaryeditar(e);	
	})
	$("#empresa").on("change",function()
	{
		elegirBeca();
	})
	$("#beca").prop("disabled",true);
	$("#beca").val(0);

}

function baja(alumnoId, nombre){
	bootbox.confirm("¿Seguro que desea dar de baja al alumno " + nombre + "?", function(result){
		if(result)
        {
        	$.post("../ajax/Alumnos.php?op=baja", {id : alumnoId}, function(e){
        		bootbox.alert(e);
	            tabla.ajax.reload();
        	});	
        }
	})
}

function alta(alumnoId, nombre){
	bootbox.confirm("¿Seguro que desea dar de alta al alumno " + nombre + "?", function(result){
		if(result)
        {
        	$.post("../ajax/Alumnos.php?op=alta", {id : alumnoId}, function(e){
        		bootbox.alert(e);
	            tabla.ajax.reload();
        	});	
        }
	})
}

function elegirBeca(){

	$("#beca").prop("disabled",false);
	var becaId = $("#empresa").find(':selected').val();
	var desc = $("#empresa").find(':selected').data('des');
	//ninguna
	if(becaId == -1){
		$("#beca").prop("disabled",true);
		$("#beca").val(0);
	}
	//ingresar beca
	if(becaId == -2){
		$("#beca").prop("disabled",false);
		$("#beca").val(0);
	}
	if(becaId > 0){
		$("#beca").prop("disabled",true);
		$("#beca").val(desc);
	}
}
//Función limpiar
function limpiar()
{
	$("#id").val("");
	$("#nombre").val("");
	$("#descripcion").val("");
	$("#nombre").val("");
	$("#apellidoP").val("");
	$("#apellidoM").val("");
	$("#calle").val("");
	$("#colonia").val("");
	$("#numero").val("");
	$("#municipio").val("");
	$("#telefono").val("");
	$("#celular").val("");
	$("#email").val("");
	$("#fecha_nacimiento").val("");
	$("#fecha_ingreso").val("");
	$("#foto").val("");
	$("#empresa").val("");
	$("#beca").val("");
	$("#sede").val("");

	$("#beca").prop("disabled",true);
	$("#id").attr("status","");
}

//Función mostrar formulario
function mostrarform(flag)
{
	$("#fotoDiv").show();
	limpiar();
	if (flag)
	{
		$("#listadoregistros").hide();
		$("#formularioregistros").show();
		$("#btnGuardar").prop("disabled",false);
		$("#btnagregar").hide();
	}
	else
	{
		$("#listadoregistros").show();
		$("#formularioregistros").hide();
		$("#btnagregar").show();
	}
}

//Función cancelarform
function cancelarform()
{
	limpiar();
	mostrarform(false);
}

//Función Listar
function listar()
{
	tabla=$('#tbllistado').dataTable(
	{
		"aProcessing": true,//Activamos el procesamiento del datatables
	    "aServerSide": true,//Paginación y filtrado realizados por el servidor
	    dom: 'Bfrtip',//Definimos los elementos del control de tabla
	    buttons: [		          
		            'copyHtml5',
		            'excelHtml5',
		            'csvHtml5',
		            'pdf'
		        ],
		"ajax":
				{
					url: '../ajax/Alumnos.php?op=listar',
					type : "get",
					dataType : "json",						
					error: function(e){
						console.log(e.responseText);	
					}
				},
		"bDestroy": true,
		"iDisplayLength": 5,//Paginación
	    "order": [[ 0, "desc" ]]//Ordenar (columna,orden)
	}).DataTable();
}
//Función para guardar o editar

function guardaryeditar(e)
{
	e.preventDefault(); //No se activará la acción predeterminada del evento
	$("#beca").prop("disabled",false);
	$("#btnGuardar").prop("disabled",true);
	$("#fotoDiv").show();
	var formData = new FormData($("#formulario")[0]);

	if($("#foto").attr("rutaFoto") != ""){
		formData.append("foto",$("#foto").attr("rutaFoto"))
	}
	
	if($("#id").attr("status") != ""){
		formData.append("status",$("#id").attr("status"))
		console.log("entro");
	}

	$.ajax({
		url: "../ajax/Alumnos.php?op=guardaryeditar",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,

	    success: function(datos)
	    {                    
	          bootbox.alert(datos);	          
	          mostrarform(false);
	          tabla.ajax.reload();
	    }

	});
	limpiar();
}

function mostrar(idAlumno,nombre)
{
	$.post("../ajax/Alumnos.php?op=mostrar",{id : idAlumno}, function(data, status)
	{
		data = JSON.parse(data);		
		mostrarform(true);

		$("#id").val(data.id);
		$("#id").attr("status",data.status);
		$("#nombre").val(data.nombre);
		$("#descripcion").val(data.descripcion);
		$("#nombre").val(data.nombre);
		$("#apellidoP").val(data.apellidoP);
		$("#apellidoM").val(data.apellidoM);
		$("#calle").val(data.calle);
		$("#colonia").val(data.colonia);
		$("#numero").val(data.numero);
		$("#municipio").val(data.municipio);
		$("#telefono").val(data.telefono);
		$("#celular").val(data.celular);
		$("#email").val(data.email);
		$("#fecha_nacimiento").val(data.fecha_nacimiento);
		$("#fecha_ingreso").val(data.fecha_ingreso);
		$("#foto").attr("rutaFoto",data.foto)
		//$("#fotoDiv").hide();
		$("#beca").val(data.beca);
		$("#sede").val(data.sede);
		listarConvenio(data.empresa);

 	})
}

//Función para desactivar registros
function desactivar(idcategoria)
{
	bootbox.confirm("¿Está Seguro de desactivar la Categoría?", function(result){
		if(result)
        {
        	$.post("../ajax/categoria.php?op=desactivar", {idcategoria : idcategoria}, function(e){
        		bootbox.alert(e);
	            tabla.ajax.reload();
        	});	
        }
	})
}

//Función para activar registros
function activar(idcategoria)
{
	bootbox.confirm("¿Está Seguro de activar la Categoría?", function(result){
		if(result)
        {
        	$.post("../ajax/categoria.php?op=activar", {idcategoria : idcategoria}, function(e){
        		bootbox.alert(e);
	            tabla.ajax.reload();
        	});	
        }
	})
}
function listarConvenio(idConvenio)
{
	if(idConvenio != undefined){
		$.ajax({
			url: "../ajax/Convenios.php?op=listar",
			type: "GET",
			contentType: false,
			processData: false,
			success: function(datos)
			{  
				var respuesta=Object.values(JSON.parse(datos));
				console.log(respuesta)
				var options = "";
				for (option of respuesta){
					if(option.id == idConvenio){
						options += "<option selected value = " + option.id + " data-des = " + option.des_mensualidad + ">" + option.nombre + "</option>";
					}else{
						options += "<option value = " + option.id + " data-des = " + option.des_mensualidad + ">" + option.nombre + "</option>";
					}
				}

				if(option.id == 0){
					options += "<option selected value = " + option.id + " data-des = " + option.des_mensualidad + ">" + option.nombre + "</option>";
				}else{
					options = "<option value = '-1'  data-des = 0>Ninguna</option><option data-des = 0 value = '-2'>Beca</option>" + options;
				}
				$('#empresa').html(options);
			}
	
		});
	}else{

	}
    $.ajax({
		url: "../ajax/Convenios.php?op=listar",
	    type: "GET",
	    contentType: false,
	    processData: false,
	    success: function(datos)
	    {  
			var respuesta=Object.values(JSON.parse(datos));
			console.log(respuesta)
			var options = "";
			for (option of respuesta){
				options += "<option value = " + option.id + " data-des = " + option.des_mensualidad + ">" + option.nombre + "</option>";
			}
			options = "<option value = '-1' selected data-des = 0>Ninguna</option><option data-des = 0 value = '-2'>Beca</option>" + options;
            $('#empresa').html(options);
	    }

	});

}

init();