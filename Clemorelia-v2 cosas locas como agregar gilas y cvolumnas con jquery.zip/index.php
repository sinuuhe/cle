<?php
//redireccionar a la vista de login
header ('Location: vistas/login.php');
